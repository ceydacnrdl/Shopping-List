const path=require('path');
const express = require('express');
const app =express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const urunEkleRoutes= require('./routes/urun-ekle.js');
const magazaRoutes= require('./routes/magaza.js');

app.use(express.static(path.join(__dirname, 'public')));
app.use('/admin',urunEkleRoutes.routes); // urun-ekle.js de routes export edildiği için
app.use(magazaRoutes);


app.use((req,res,next) => {
  //res.status(404).send('<h1>Üzgünüz Sayfanız Görüntülenemiyor</h1>');

  res.status(404).render('404', {
    sayfa_basligi:'Page not found',
    path:''
  });
});






app.listen(3000);
