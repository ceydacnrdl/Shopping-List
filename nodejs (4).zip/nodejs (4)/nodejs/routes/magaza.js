const path = require('path');
const express = require('express');
const router = express.Router();
const baglanti=require('../util/vt_baglanti');

router.get('/', (req,res,next) => {



  baglanti.getConnection(function(err) {
    if (err) throw err;
    baglanti.query("SELECT U.*, T.tip_adi, T.renk_kodu FROM urun AS U INNER JOIN urun_tip AS T ON T.id=U.urun_tip_id ", function (err, result, fields) {
      if (err) throw err;
      //console.log(result);

      res.render('magaza', {
        sayfa_basligi:'Mağazamız',
        path:'/',
        urun:result
      });
    });
  });


})

module.exports=router;
