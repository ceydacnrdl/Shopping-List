const path = require('path');
const express = require('express');
const router = express.Router();

const bodyParser=require('body-parser');
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended:false}));

const baglanti=require('../util/vt_baglanti');

const urunler=[];

router.get('/urun-ekle', (req,res,next) => {
  baglanti.getConnection(function(err) {
    if (err) throw err;
    baglanti.query("SELECT * FROM urun_tip", function (err, result, fields) {
      if (err) throw err;
      res.render('urun-ekle', {
        sayfa_basligi:'Ürün Ekle',
        path:'/admin/urun-ekle',
        urun_tip:result
      });
    });
  });

})

router.post('/urun-ekle', (req,res,next) => {

  baglanti.getConnection(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO urun (urun_adi,fiyat, urun_tip_id) VALUES ('"+req.body.urun_adi+"','"+req.body.fiyat+"','"+req.body.urun_tip_id+"')";
    baglanti.query(sql, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
    });
  });
  res.redirect('/');
});

//module.exports=router;

exports.routes=router;
exports.urunler=urunler;
