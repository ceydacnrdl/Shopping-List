const mysql = require('mysql');

const baglanti = mysql.createPool({
  connectionLimit:100,
  host: "localhost",
  user: "root",
  password: "",
  database: "ileriweb"
});

module.exports=baglanti;
