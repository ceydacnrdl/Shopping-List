-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 04 Haz 2022, 20:44:35
-- Sunucu sürümü: 10.4.20-MariaDB
-- PHP Sürümü: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ileriweb`
--
CREATE DATABASE IF NOT EXISTS `ileriweb` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `ileriweb`;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urun`
--

CREATE TABLE `urun` (
  `id` int(10) UNSIGNED NOT NULL,
  `urun_adi` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `fiyat` decimal(6,2) NOT NULL,
  `urun_tip_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `urun`
--

INSERT INTO `urun` (`id`, `urun_adi`, `fiyat`, `urun_tip_id`) VALUES
(1, 'Karpuz', '90.45', 1),
(2, 'Kiraz', '20.50', 1),
(3, 'Çilek', '0.00', 1),
(4, 'Avokado', '30.00', 2),
(5, 'Ceviz İçi', '150.55', 3),
(6, 'Roket Başlığı', '56.00', 4),
(7, 'Sabun', '69.00', 5);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urun_tip`
--

CREATE TABLE `urun_tip` (
  `id` int(10) UNSIGNED NOT NULL,
  `tip_adi` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `renk_kodu` varchar(16) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `urun_tip`
--

INSERT INTO `urun_tip` (`id`, `tip_adi`, `renk_kodu`) VALUES
(1, 'Meyve', 'F6C6EA'),
(2, 'Sebze', 'CDF0EA'),
(3, 'Kuruyemiş', 'C1A3A3'),
(4, 'Uzay Araç Gereç', 'ccc'),
(5, 'Temizlik Malzemesi', 'eda');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `urun`
--
ALTER TABLE `urun`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `urun_tip`
--
ALTER TABLE `urun_tip`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `urun`
--
ALTER TABLE `urun`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `urun_tip`
--
ALTER TABLE `urun_tip`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
